package com.mycompany.mypizza.repository;

public interface LoginRepository {
	String selectId(String username);

}
